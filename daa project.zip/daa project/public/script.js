document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('file-input');
    const dropArea = document.getElementById('drop-area');
    const fileInfo = document.getElementById('file-info');
    const fileNameDisplay = document.getElementById('file-name');
    const removeBtn = document.getElementById('remove-file');
    const uploadLabel = document.querySelector('.upload-label');
    
    const compressBtn = document.getElementById('compress-btn');
    const decompressBtn = document.getElementById('decompress-btn');
    
    const statusContainer = document.getElementById('status-container');
    const statusText = document.getElementById('status-text');
    const errorContainer = document.getElementById('error-container');
    const errorText = document.getElementById('error-text');

    let currentFile = null;

    // Handle File Selection
    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    // Drag & Drop Events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, () => dropArea.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, () => dropArea.classList.remove('dragover'), false);
    });

    dropArea.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    });

    function handleFiles(files) {
        if (files.length > 0) {
            currentFile = files[0];
            updateUIWithFile();
        }
    }

    function updateUIWithFile() {
        fileNameDisplay.textContent = currentFile.name;
        uploadLabel.classList.add('hidden');
        fileInfo.classList.remove('hidden');
        errorContainer.classList.add('hidden');
        
        // Enable buttons
        compressBtn.disabled = false;
        decompressBtn.disabled = false;
    }

    // Remove file
    removeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation(); // prevent clicking drop area
        currentFile = null;
        fileInput.value = '';
        
        uploadLabel.classList.remove('hidden');
        fileInfo.classList.add('hidden');
        
        compressBtn.disabled = true;
        decompressBtn.disabled = true;
    });

    // Process File Function
    async function processFile(action) {
        if (!currentFile) return;

        // UI Feedback
        compressBtn.disabled = true;
        decompressBtn.disabled = true;
        removeBtn.disabled = true;
        statusContainer.classList.remove('hidden');
        errorContainer.classList.add('hidden');
        
        statusText.textContent = action === 'compress' ? 'Compressing...' : 'Decompressing...';

        const formData = new FormData();
        formData.append('file', currentFile);

        try {
            const response = await fetch(`http://localhost:3000/${action}`, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            // Get filename from Content-Disposition header if possible, otherwise construct it
            let filename = action === 'compress' ? `${currentFile.name}.huff` : `decompressed_${currentFile.name.replace('.huff', '')}`;
            
            const disposition = response.headers.get('Content-Disposition');
            if (disposition && disposition.indexOf('attachment') !== -1) {
                const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                const matches = filenameRegex.exec(disposition);
                if (matches != null && matches[1]) { 
                    filename = matches[1].replace(/['"]/g, '');
                }
            }

            const blob = await response.blob();
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = downloadUrl;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(downloadUrl);
            
            statusText.textContent = 'Success!';
            setTimeout(() => {
                statusContainer.classList.add('hidden');
                // Re-enable UI
                compressBtn.disabled = false;
                decompressBtn.disabled = false;
                removeBtn.disabled = false;
            }, 2000);

        } catch (error) {
            console.error('Error:', error);
            statusContainer.classList.add('hidden');
            errorContainer.classList.remove('hidden');
            errorText.textContent = `Error: ${error.message}`;
            
            // Re-enable UI
            compressBtn.disabled = false;
            decompressBtn.disabled = false;
            removeBtn.disabled = false;
        }
    }

    compressBtn.addEventListener('click', () => processFile('compress'));
    decompressBtn.addEventListener('click', () => processFile('decompress'));
});
