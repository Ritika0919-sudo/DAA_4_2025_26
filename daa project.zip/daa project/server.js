const express = require('express');
const multer = require('multer');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('public')); // Serve frontend files

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Ensure uploads directory exists
if (!fs.existsSync('uploads')) {
    fs.mkdirSync('uploads');
}

// Compress endpoint
app.post('/compress', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    const inputPath = req.file.path;
    const outputPath = inputPath + '.huff';
    const originalName = req.file.originalname;

    // Command to execute C++ program
    // Note: Assuming huffman.exe is compiled in the same directory
    const command = `huffman.exe -c "${inputPath}" "${outputPath}"`;

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing C++ program: ${error}`);
            console.error(`stderr: ${stderr}`);
            return res.status(500).send('Compression failed.');
        }

        console.log(`stdout: ${stdout}`);
        
        // Send the compressed file
        res.download(outputPath, `${originalName}.huff`, (err) => {
            if (err) {
                console.error('Error sending file:', err);
            }
            // Cleanup files
            fs.unlinkSync(inputPath);
            fs.unlinkSync(outputPath);
        });
    });
});

// Decompress endpoint
app.post('/decompress', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    const inputPath = req.file.path;
    const originalName = req.file.originalname;
    
    // Remove .huff extension if present
    let downloadName = originalName;
    if (downloadName.endsWith('.huff')) {
        downloadName = downloadName.slice(0, -5);
    } else {
        downloadName = "decompressed_" + downloadName;
    }
    
    const outputPath = inputPath + '_decompressed';

    const command = `huffman.exe -d "${inputPath}" "${outputPath}"`;

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing C++ program: ${error}`);
            console.error(`stderr: ${stderr}`);
            return res.status(500).send('Decompression failed.');
        }

        console.log(`stdout: ${stdout}`);
        
        // Send the decompressed file
        res.download(outputPath, downloadName, (err) => {
            if (err) {
                console.error('Error sending file:', err);
            }
            // Cleanup files
            fs.unlinkSync(inputPath);
            fs.unlinkSync(outputPath);
        });
    });
});

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
