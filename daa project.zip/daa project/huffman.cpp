#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <string>

using namespace std;

// Node for Huffman Tree
struct Node {
    char data;
    int freq;
    Node* left;
    Node* right;

    Node(char d, int f) : data(d), freq(f), left(nullptr), right(nullptr) {}
};

// Compare struct for priority queue
struct Compare {
    bool operator()(Node* l, Node* r) {
        return l->freq > r->freq;
    }
};

// Traverse Huffman Tree and generate codes
void generateCodes(Node* root, string str, unordered_map<char, string>& huffmanCode) {
    if (root == nullptr) return;

    if (!root->left && !root->right) {
        huffmanCode[root->data] = str;
    }

    generateCodes(root->left, str + "0", huffmanCode);
    generateCodes(root->right, str + "1", huffmanCode);
}

// Compress function
void compress(const string& inputFile, const string& outputFile) {
    ifstream inFile(inputFile, ios::binary);
    if (!inFile) {
        cerr << "Cannot open input file." << endl;
        return;
    }

    // Read input file
    string text((istreambuf_iterator<char>(inFile)), istreambuf_iterator<char>());
    inFile.close();

    if (text.empty()) {
        ofstream outFile(outputFile, ios::binary);
        return;
    }

    // Calculate frequencies
    unordered_map<char, int> freq;
    for (char c : text) {
        freq[c]++;
    }

    // Create priority queue
    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto pair : freq) {
        pq.push(new Node(pair.first, pair.second));
    }

    // Build Huffman Tree
    while (pq.size() != 1) {
        Node* left = pq.top(); pq.pop();
        Node* right = pq.top(); pq.pop();

        int sum = left->freq + right->freq;
        Node* node = new Node('\0', sum);
        node->left = left;
        node->right = right;
        pq.push(node);
    }

    Node* root = pq.top();

    // Generate codes
    unordered_map<char, string> huffmanCode;
    generateCodes(root, "", huffmanCode);

    // Encode text
    string encodedStr = "";
    for (char c : text) {
        encodedStr += huffmanCode[c];
    }

    // Write to output file
    ofstream outFile(outputFile, ios::binary);
    if (!outFile) {
        cerr << "Cannot open output file." << endl;
        return;
    }

    // Write header: number of unique characters
    int uniqueChars = freq.size();
    outFile.write(reinterpret_cast<const char*>(&uniqueChars), sizeof(uniqueChars));

    // Write character-frequency pairs
    for (auto pair : freq) {
        outFile.write(&pair.first, sizeof(pair.first));
        outFile.write(reinterpret_cast<const char*>(&pair.second), sizeof(pair.second));
    }

    // Write number of valid bits in the last byte
    int validBits = encodedStr.length() % 8;
    if (validBits == 0 && encodedStr.length() > 0) validBits = 8;
    outFile.write(reinterpret_cast<const char*>(&validBits), sizeof(validBits));

    // Convert string of bits to bytes and write
    unsigned char byte = 0;
    int bitCount = 0;
    for (char bit : encodedStr) {
        byte = (byte << 1) | (bit - '0');
        bitCount++;
        if (bitCount == 8) {
            outFile.write(reinterpret_cast<const char*>(&byte), sizeof(byte));
            byte = 0;
            bitCount = 0;
        }
    }
    if (bitCount > 0) {
        byte = byte << (8 - bitCount);
        outFile.write(reinterpret_cast<const char*>(&byte), sizeof(byte));
    }

    outFile.close();
    cout << "Compression successful." << endl;
}

// Decompress function
void decompress(const string& inputFile, const string& outputFile) {
    ifstream inFile(inputFile, ios::binary);
    if (!inFile) {
        cerr << "Cannot open input file." << endl;
        return;
    }

    // Read header: number of unique characters
    int uniqueChars;
    if (!inFile.read(reinterpret_cast<char*>(&uniqueChars), sizeof(uniqueChars))) {
        ofstream outFile(outputFile, ios::binary); // Empty file
        return;
    }

    // Read character-frequency pairs and rebuild priority queue
    unordered_map<char, int> freq;
    for (int i = 0; i < uniqueChars; i++) {
        char c;
        int f;
        inFile.read(&c, sizeof(c));
        inFile.read(reinterpret_cast<char*>(&f), sizeof(f));
        freq[c] = f;
    }

    // Read number of valid bits in the last byte
    int validBits;
    inFile.read(reinterpret_cast<char*>(&validBits), sizeof(validBits));

    if (freq.empty()) {
        return;
    }

    // Build Huffman Tree
    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto pair : freq) {
        pq.push(new Node(pair.first, pair.second));
    }

    while (pq.size() != 1) {
        Node* left = pq.top(); pq.pop();
        Node* right = pq.top(); pq.pop();

        int sum = left->freq + right->freq;
        Node* node = new Node('\0', sum);
        node->left = left;
        node->right = right;
        pq.push(node);
    }

    Node* root = pq.top();

    // Read compressed data
    vector<unsigned char> bytes;
    char byte;
    while (inFile.get(byte)) {
        bytes.push_back(static_cast<unsigned char>(byte));
    }
    inFile.close();

    // Decode
    string decodedStr = "";
    Node* current = root;
    for (size_t i = 0; i < bytes.size(); i++) {
        int bitsToRead = (i == bytes.size() - 1) ? validBits : 8;
        if (bitsToRead == 0) bitsToRead = 8; // if length % 8 == 0, validBits might be 0 or 8. We set it to 8.

        for (int j = 7; j >= 8 - bitsToRead; j--) {
            int bit = (bytes[i] >> j) & 1;
            if (bit == 0) {
                current = current->left;
            } else {
                current = current->right;
            }

            if (!current->left && !current->right) {
                decodedStr += current->data;
                current = root;
            }
        }
    }

    // Write to output file
    ofstream outFile(outputFile, ios::binary);
    if (!outFile) {
        cerr << "Cannot open output file." << endl;
        return;
    }
    outFile.write(decodedStr.c_str(), decodedStr.length());
    outFile.close();
    cout << "Decompression successful." << endl;
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " <mode: -c/-d> <input_file> <output_file>" << endl;
        return 1;
    }

    string mode = argv[1];
    string inputFile = argv[2];
    string outputFile = argv[3];

    if (mode == "-c") {
        compress(inputFile, outputFile);
    } else if (mode == "-d") {
        decompress(inputFile, outputFile);
    } else {
        cerr << "Invalid mode. Use -c for compress and -d for decompress." << endl;
        return 1;
    }

    return 0;
}
